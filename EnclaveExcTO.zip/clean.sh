#! /bin/bash
(cd ./Enclave_B/ && make clean) & (cd ./Enclave_A/ && make clean)
